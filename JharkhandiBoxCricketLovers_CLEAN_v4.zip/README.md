# Jharkhandi Box Cricket Lovers

Offline Android box-cricket scorecard app. No ads and no account required.

Features:
- Runs: 1, 2, 3, 4 and 6
- Dot ball
- Wickets
- Overs calculation
- Match-end score display
