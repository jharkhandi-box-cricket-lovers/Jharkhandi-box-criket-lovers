package com.jharkhandi.boxcricketlovers;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root, scoreRow;
    TextView score, wickets, overs, teamA, teamB;
    int runs = 0, outs = 0, balls = 0;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    TextView tv(String text, float size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(Color.DKGRAY);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        return t;
    }

    Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        return b;
    }

    void update() {
        score.setText(runs + "/" + outs);
        overs.setText((balls / 6) + "." + (balls % 6) + " overs");
        wickets.setText("Wickets: " + outs);
    }

    void addRuns(int n) {
        runs += n;
        balls++;
        update();
    }

    void wicket() {
        if (outs < 10) outs++;
        balls++;
        update();
    }

    void matchEnd() {
        new AlertDialog.Builder(this)
            .setTitle("Match Saved")
            .setMessage("Final score: " + runs + "/" + outs + " in " +
                        (balls / 6) + "." + (balls % 6) + " overs")
            .setPositiveButton("OK", null)
            .show();
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(14));
        root.setBackgroundColor(Color.rgb(245,247,245));

        TextView title = tv("🏏 Jharkhandi Box Cricket Lovers", 22);
        title.setTextColor(Color.rgb(27,94,32));
        title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(58)));

        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.HORIZONTAL);
        teamA = tv("Team A", 18); teamB = tv("Team B", 18);
        names.addView(teamA, new LinearLayout.LayoutParams(0, dp(55), 1));
        names.addView(teamB, new LinearLayout.LayoutParams(0, dp(55), 1));
        root.addView(names);

        score = tv("0/0", 46);
        score.setTextColor(Color.rgb(27,94,32));
        score.setTypeface(null, 1);
        root.addView(score, new LinearLayout.LayoutParams(-1, dp(90)));

        overs = tv("0.0 overs", 18);
        wickets = tv("Wickets: 0", 16);
        root.addView(overs);
        root.addView(wickets);

        scoreRow = new LinearLayout(this);
        scoreRow.setOrientation(LinearLayout.VERTICAL);

        int[] vals = {0,1,2,3,4,6};
        for (int v : vals) {
            Button b = btn(v == 0 ? "Dot Ball" : "+" + v + " Runs");
            b.setOnClickListener(x -> addRuns(v));
            scoreRow.addView(b, new LinearLayout.LayoutParams(-1, dp(52)));
        }

        Button w = btn("WICKET");
        w.setOnClickListener(x -> wicket());
        scoreRow.addView(w, new LinearLayout.LayoutParams(-1, dp(52)));

        Button end = btn("MATCH END / SAVE SCORE");
        end.setOnClickListener(x -> matchEnd());
        scoreRow.addView(end, new LinearLayout.LayoutParams(-1, dp(58)));

        root.addView(scoreRow, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }
}
