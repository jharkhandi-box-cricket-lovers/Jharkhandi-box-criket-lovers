package com.jharkhandiboxcricketlovers;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    final int GREEN=Color.rgb(8,122,54), BLUE=Color.rgb(8,125,204), RED=Color.rgb(217,48,37), GOLD=Color.rgb(245,180,0);
    LinearLayout root, content, nav;
    SharedPreferences prefs;
    JSONObject match;
    int innings=0;
    ArrayList<String> undoStack = new ArrayList<>();

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(16,35,26)); t.setPadding(dp(8),dp(6),dp(8),dp(6)); return t; }
    Button btn(String s,int color){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setAllCaps(false); b.setBackgroundColor(color); b.setPadding(dp(4),dp(2),dp(4),dp(2)); return b; }
    EditText input(String hint,String value){ EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setTextSize(15); e.setSingleLine(true); e.setPadding(dp(12),0,dp(12),0); return e; }
    LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(14),dp(12),dp(14),dp(12)); l.setBackgroundColor(Color.WHITE); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(dp(8),dp(7),dp(8),dp(7)); l.setLayoutParams(p); return l; }
    void clear(){ content.removeAllViews(); }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("jbcsl",0); buildShell(); home(); }
    void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(243,246,244));
        LinearLayout head=new LinearLayout(this); head.setOrientation(LinearLayout.VERTICAL); head.setPadding(dp(16),dp(13),dp(16),dp(10)); head.setBackgroundColor(GREEN);
        TextView h=tv("🏏 Jharkhandi Box Cricket Lovers",20); h.setTextColor(Color.WHITE); h.setTypeface(null,1);
        TextView sub=tv("No Ads • 100% Free • Offline",12); sub.setTextColor(Color.WHITE); sub.setAlpha(.85f); head.addView(h); head.addView(sub); root.addView(head);
        ScrollView sv=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(0,dp(4),0,dp(78)); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.WHITE);
        String[] ns={"🏠\nHome","➕\nNew Match","🏆\nMatches","📊\nStats"}; for(String n:ns){ Button x=new Button(this); x.setText(n); x.setTextSize(11); x.setAllCaps(false); x.setBackgroundColor(Color.TRANSPARENT); nav.addView(x,new LinearLayout.LayoutParams(0,dp(62),1)); }
        nav.getChildAt(0).setOnClickListener(v->home()); nav.getChildAt(1).setOnClickListener(v->newMatch()); nav.getChildAt(2).setOnClickListener(v->history()); nav.getChildAt(3).setOnClickListener(v->stats());
        root.addView(nav); setContentView(root);
    }

    void home(){
        clear(); LinearLayout c=card(); TextView title=tv("Jharkhandi Box Cricket Lovers",22); title.setTypeface(null,1); c.addView(title);
        c.addView(tv("Box cricket ke liye professional-style scorer.",14));
        Button n=btn("➕  New Match",GREEN); c.addView(n); n.setOnClickListener(v->newMatch());
        Button h=btn("🏆  Match History",BLUE); c.addView(h); h.setOnClickListener(v->history());
        Button r=btn("▶  Resume Current Match",Color.DKGRAY); c.addView(r); r.setOnClickListener(v->resumeCurrent());
        content.addView(c);
        LinearLayout g=new LinearLayout(this); g.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout a=card(); a.addView(tv("📴 Offline",17)); a.addView(tv("Internet ke bina",12)); g.addView(a,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout d=card(); d.addView(tv("🚫 No Ads",17)); d.addView(tv("Koi advertisement nahi",12)); g.addView(d,new LinearLayout.LayoutParams(0,-2,1)); content.addView(g);
    }

    void newMatch(){
        clear(); LinearLayout c=card(); c.addView(tv("New Match",22));
        EditText mn=input("Match Name","Box Cricket Match"); c.addView(mn);
        EditText ta=input("Team A","Jharkhandi Warriors"); c.addView(ta);
        EditText tb=input("Team B","Box Cricket Champions"); c.addView(tb);
        Spinner ov=new Spinner(this); String[] os={"4","6","8","10","12","20"}; ov.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,os)); c.addView(tv("Overs",12)); c.addView(ov);
        EditText pc=input("Players per team","6"); pc.setInputType(2); c.addView(pc);
        Button create=btn("CREATE MATCH",GREEN); c.addView(create); content.addView(c);
        create.setOnClickListener(v->{ try{
            match=new JSONObject(); match.put("name",mn.getText().toString()); JSONArray teams=new JSONArray(); teams.put(ta.getText().toString()); teams.put(tb.getText().toString()); match.put("teams",teams);
            match.put("overs",Integer.parseInt(ov.getSelectedItem().toString())); match.put("pc",Math.max(2,Math.min(20,Integer.parseInt(pc.getText().toString()))));
            match.put("s0",new JSONObject().put("r",0).put("w",0).put("b",0)); match.put("s1",new JSONObject().put("r",0).put("w",0).put("b",0));
            match.put("balls0",new JSONArray()); match.put("balls1",new JSONArray()); match.put("batters0",new JSONArray()); match.put("batters1",new JSONArray());
            match.put("bowler0","Bowler"); match.put("bowler1","Bowler"); match.put("toss",0); match.put("battingFirst",0); innings=0; undoStack.clear(); tossScreen();
        }catch(Exception e){toast("Match create nahi hua");}});
    }

    void tossScreen(){
        clear(); LinearLayout c=card(); c.addView(tv("🪙 Toss",23)); c.addView(tv("Toss winner select kijiye",14));
        Spinner win=new Spinner(this); win.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{teamName(0),teamName(1)})); c.addView(tv("Toss Winner",12)); c.addView(win);
        Spinner choice=new Spinner(this); choice.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Bat","Bowl"})); c.addView(tv("Decision",12)); c.addView(choice);
        Button go=btn("CONTINUE",GREEN); c.addView(go); content.addView(c);
        go.setOnClickListener(v->{int winner=win.getSelectedItemPosition(); int batting=(choice.getSelectedItemPosition()==0)?winner:1-winner; try{match.put("toss",winner);match.put("battingFirst",batting);innings=batting;}catch(Exception e){} playerSetup();});
    }

    void playerSetup(){
        clear(); LinearLayout c=card(); c.addView(tv("Players – "+teamName(innings),21)); c.addView(tv("Har player ka naam add karein",13));
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); c.addView(list);
        int n=match.optInt("pc",6); ArrayList<EditText> fields=new ArrayList<>();
        for(int i=1;i<=n;i++){ EditText e=input("Player "+i,""); fields.add(e); list.addView(e); }
        Button start=btn("START MATCH",GREEN); c.addView(start); content.addView(c);
        start.setOnClickListener(v->{ try{
            JSONArray a=new JSONArray(); for(EditText e:fields) if(!e.getText().toString().trim().isEmpty()) a.put(e.getText().toString().trim());
            while(a.length()<2)a.put("Batter "+(a.length()+1));
            match.put("p"+innings,a); match.put("striker"+innings,a.getString(0)); match.put("non"+innings,a.getString(1));
            JSONArray stats=new JSONArray(); for(int i=0;i<a.length();i++)stats.put(new JSONObject().put("name",a.getString(i)).put("r",0).put("b",0).put("f4",0).put("f6",0).put("out",false));
            match.put("batters"+innings,stats); saveCurrent(); live();
        }catch(Exception e){toast("Player save error");}});
    }

    String teamName(int i){return match.optJSONArray("teams").optString(i,"Team");}
    JSONObject score(){return match.optJSONObject("s"+innings);}
    JSONArray balls(){return match.optJSONArray("balls"+innings);}
    JSONArray batStats(){return match.optJSONArray("batters"+innings);}

    void live(){
        clear(); JSONObject s=score(); LinearLayout c=card(); TextView title=tv(teamName(innings),18); title.setTypeface(null,1); c.addView(title);
        TextView sc=tv(s.optInt("r")+"/"+s.optInt("w"),40); sc.setTextColor(innings==0?GREEN:BLUE); c.addView(sc);
        int legal=s.optInt("b"); String target=s.has("target")?" • Target "+s.optInt("target"):"";
        c.addView(tv((legal/6)+"."+(legal%6)+" overs / "+match.optInt("overs")+target,13));
        c.addView(tv("🟢 "+match.optString("striker"+innings)+"*    "+match.optString("non"+innings),13));
        c.addView(tv("🎳 Bowler: "+match.optString("bowler"+innings,"Bowler"),13)); content.addView(c);

        LinearLayout r=card(); r.addView(tv("⚡ Add Runs",19)); LinearLayout rg=new LinearLayout(this); rg.setOrientation(LinearLayout.HORIZONTAL);
        int[] runs={0,1,2,3,4,6}; for(int rr:runs){ Button b=btn(""+rr,(rr==4||rr==6)?BLUE:GREEN); rg.addView(b,new LinearLayout.LayoutParams(0,dp(55),1)); b.setOnClickListener(v->addRuns(rr,true,""+rr)); } r.addView(rg); content.addView(r);

        LinearLayout ex=card(); ex.addView(tv("Extras / Wicket",18));
        String[] es={"Wide","No Ball","Bye","Leg Bye","Bowled","Caught","LBW","Run Out","Stumped"}; for(String x:es){Button b=btn(x,(x.equals("Bowled")||x.equals("Caught")||x.equals("LBW")||x.equals("Run Out")||x.equals("Stumped"))?RED:GOLD); ex.addView(b); b.setOnClickListener(v->{if(x.equals("Wide"))addRuns(1,false,"WD");else if(x.equals("No Ball"))addRuns(1,false,"NB");else if(x.equals("Bye"))addRuns(0,true,"B");else if(x.equals("Leg Bye"))addRuns(0,true,"LB");else wicket(x);});}
        Button bow=btn("🎳 Change Bowler",BLUE); ex.addView(bow); bow.setOnClickListener(v->chooseBowler()); content.addView(ex);

        LinearLayout tools=card(); tools.addView(tv("Match Controls",18));
        Button undo=btn("↩ Undo Last Ball",Color.DKGRAY); tools.addView(undo); undo.setOnClickListener(v->undo());
        Button edit=btn("✏ Edit Current Score",Color.DKGRAY); tools.addView(edit); edit.setOnClickListener(v->editScore());
        Button share=btn("📤 Share Live Score",BLUE); tools.addView(share); share.setOnClickListener(v->shareScore());
        Button board=btn("📋 Full Scorecard",GREEN); tools.addView(board); board.setOnClickListener(v->scorecard()); content.addView(tools);

        LinearLayout over=card(); over.addView(tv("Current Over",17)); StringBuilder bs=new StringBuilder(); JSONArray ba=balls(); for(int i=Math.max(0,ba.length()-6);i<ba.length();i++)bs.append(" ").append(ba.optString(i)); over.addView(tv(bs.length()>0?bs.toString():"No balls yet",14)); content.addView(over);
    }

    void snapshot(){
        try{undoStack.add(match.toString()); if(undoStack.size()>30)undoStack.remove(0);}catch(Exception e){}
    }

    void addRuns(int r,boolean legal,String label){
        try{
            snapshot(); JSONObject s=score(); s.put("r",s.optInt("r")+r); if(legal)s.put("b",s.optInt("b")+1); balls().put(label);
            if(legal)updateBatter(r);
            if(r%2==1 && legal)swapStriker();
            saveCurrent(); if(checkEnd())return;
            if(legal && s.optInt("b")%6==0 && s.optInt("b")>0)swapStriker();
            live();
        }catch(Exception e){toast("Scoring error");}
    }

    void updateBatter(int r){
        try{JSONArray a=batStats();String striker=match.optString("striker"+innings);for(int i=0;i<a.length();i++){JSONObject p=a.getJSONObject(i);if(p.optString("name").equals(striker)){p.put("r",p.optInt("r")+r);p.put("b",p.optInt("b")+1);if(r==4)p.put("f4",p.optInt("f4")+1);if(r==6)p.put("f6",p.optInt("f6")+1);break;}}}catch(Exception e){}
    }
    void swapStriker(){String a=match.optString("striker"+innings),b=match.optString("non"+innings);try{match.put("striker"+innings,b);match.put("non"+innings,a);}catch(Exception e){}}

    boolean checkEnd(){
        JSONObject s=score(); if(s.optInt("r")>=s.optInt("target",Integer.MAX_VALUE)){matchEnd();return true;}
        if(s.optInt("b")/6>=match.optInt("overs") || s.optInt("w")>=match.optInt("pc")-1){endInnings();return true;} return false;
    }

    void wicket(String type){
        try{
            snapshot(); JSONObject s=score(); s.put("w",s.optInt("w")+1); s.put("b",s.optInt("b")+1); balls().put("W");
            String out=match.optString("striker"+innings); JSONArray a=batStats(); for(int i=0;i<a.length();i++){JSONObject p=a.getJSONObject(i);if(p.optString("name").equals(out)){p.put("out",true);break;}}
            saveCurrent(); if(s.optInt("b")/6>=match.optInt("overs") || s.optInt("w")>=match.optInt("pc")-1){endInnings();return;}
            chooseNewBatter();
        }catch(Exception e){toast("Wicket error");}
    }

    void chooseNewBatter(){
        JSONArray a=batStats(); ArrayList<String> names=new ArrayList<>();for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(!p.optBoolean("out")&&!p.optString("name").equals(match.optString("non"+innings)))names.add(p.optString("name"));}
        if(names.isEmpty()){endInnings();return;}
        new AlertDialog.Builder(this).setTitle("New Batsman").setItems(names.toArray(new String[0]),(d,w)->{try{match.put("striker"+innings,names.get(w));saveCurrent();live();}catch(Exception e){}}).show();
    }

    void chooseBowler(){
        int bowlingTeam=1-innings; JSONArray p=match.optJSONArray("p"+bowlingTeam); ArrayList<String> names=new ArrayList<>();if(p!=null)for(int i=0;i<p.length();i++)names.add(p.optString(i));
        if(names.isEmpty()){toast("Bowling team players pehle add karein");return;}
        new AlertDialog.Builder(this).setTitle("Select Bowler").setItems(names.toArray(new String[0]),(d,w)->{try{match.put("bowler"+innings,names.get(w));saveCurrent();live();}catch(Exception e){}}).show();
    }

    void endInnings(){
        if(innings==0){
            try{JSONObject s0=match.optJSONObject("s0"); innings=1; match.optJSONObject("s1").put("target",s0.optInt("r")+1);}catch(Exception e){}
            if(!match.has("p1"))playerSetup();else live();
        } else matchEnd();
    }

    void matchEnd(){
        try{
            int a=match.optJSONObject("s0").optInt("r"), b=match.optJSONObject("s1").optInt("r");
            String result=a==b?"Match Tied":(a>b?teamName(0):teamName(1))+" won";
            match.put("result",result); match.put("time",new Date().toString());
            JSONArray hist=new JSONArray(prefs.getString("history","[]")); hist.put(match); prefs.edit().putString("history",hist.toString()).remove("current").apply();
            clear(); LinearLayout c=card(); c.addView(tv("🏆 Match Finished",24)); c.addView(tv(result,22)); c.addView(tv(teamName(0)+": "+a+" runs\\n"+teamName(1)+": "+b+" runs",15));
            Button sh=btn("📤 Share Result",BLUE); c.addView(sh); sh.setOnClickListener(v->shareText(result+"\\n"+teamName(0)+": "+a+"\\n"+teamName(1)+": "+b+"\\nJharkhandi Box Cricket Lovers"));
            Button h=btn("VIEW MATCHES",GREEN); c.addView(h); content.addView(c); h.setOnClickListener(v->history()); match=null;
        }catch(Exception e){toast("Result save error");}
    }

    void undo(){
        if(undoStack.isEmpty()){toast("Undo ke liye kuch nahi hai");return;}
        try{match=new JSONObject(undoStack.remove(undoStack.size()-1));saveCurrent();live();}catch(Exception e){toast("Undo failed");}
    }

    void editScore(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(20),dp(5),dp(20),dp(5));
        EditText r=input("Runs",""+score().optInt("r"));r.setInputType(2);EditText w=input("Wickets",""+score().optInt("w"));w.setInputType(2);EditText b=input("Legal balls",""+score().optInt("b"));b.setInputType(2);l.addView(r);l.addView(w);l.addView(b);
        new AlertDialog.Builder(this).setTitle("Edit Current Score").setView(l).setNegativeButton("Cancel",null).setPositiveButton("SAVE",(d,x)->{try{snapshot();score().put("r",Integer.parseInt(r.getText().toString()));score().put("w",Integer.parseInt(w.getText().toString()));score().put("b",Integer.parseInt(b.getText().toString()));saveCurrent();live();}catch(Exception e){toast("Invalid score");}}).show();
    }

    void scorecard(){
        clear(); LinearLayout c=card(); c.addView(tv("📋 Full Scorecard",22));
        for(int i=0;i<2;i++){JSONObject s=match.optJSONObject("s"+i);c.addView(tv(teamName(i)+"  "+s.optInt("r")+"/"+s.optInt("w")+"  ("+(s.optInt("b")/6)+"."+(s.optInt("b")%6)+")",18));JSONArray a=match.optJSONArray("batters"+i);if(a!=null)for(int j=0;j<a.length();j++){JSONObject p=a.optJSONObject(j);c.addView(tv(p.optString("name")+(p.optBoolean("out")?"":" *")+"  "+p.optInt("r")+" ("+p.optInt("b")+")  4s:"+p.optInt("f4")+"  6s:"+p.optInt("f6"),12));}}
        Button b=btn("← Back to Live Score",GREEN); c.addView(b); content.addView(c); b.setOnClickListener(v->live());
    }

    String scoreText(){
        if(match==null)return "No live match";
        JSONObject s=score();return teamName(0)+" "+match.optJSONObject("s0").optInt("r")+"/"+match.optJSONObject("s0").optInt("w")+" | "+teamName(1)+" "+match.optJSONObject("s1").optInt("r")+"/"+match.optJSONObject("s1").optInt("w");
    }
    void shareScore(){shareText("🏏 "+match.optString("name")+"\\n"+scoreText()+"\\n"+teamName(innings)+" "+score().optInt("r")+"/"+score().optInt("w")+" ("+(score().optInt("b")/6)+"."+(score().optInt("b")%6)+")\\nJharkhandi Box Cricket Lovers");}
    void shareText(String text){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,"Share Scorecard"));}

    void history(){
        clear(); LinearLayout c=card(); c.addView(tv("🏆 Match History",22)); try{JSONArray h=new JSONArray(prefs.getString("history","[]"));if(h.length()==0)c.addView(tv("Abhi koi completed match nahi hai.",14));for(int i=h.length()-1;i>=0;i--){JSONObject m=h.getJSONObject(i);c.addView(tv(m.optString("name")+"\\n"+m.optString("result")+"\\n"+m.optString("time")+"\\n"+m.optJSONObject("s0").optInt("r")+"/"+m.optJSONObject("s0").optInt("w")+" - "+m.optJSONObject("s1").optInt("r")+"/"+m.optJSONObject("s1").optInt("w"),14));}}catch(Exception e){}content.addView(c);
    }

    void stats(){
        clear(); LinearLayout c=card(); c.addView(tv("📊 Player Statistics",22)); HashMap<String,int[]> map=new HashMap<>();
        try{JSONArray h=new JSONArray(prefs.getString("history","[]"));for(int k=0;k<h.length();k++){JSONObject m=h.getJSONObject(k);for(int ti=0;ti<2;ti++){JSONArray a=m.optJSONArray("batters"+ti);if(a==null)continue;for(int j=0;j<a.length();j++){JSONObject p=a.getJSONObject(j);String n=p.optString("name");int[] v=map.containsKey(n)?map.get(n):new int[5];v[0]++;v[1]+=p.optInt("r");v[2]+=p.optInt("b");v[3]+=p.optInt("f4");v[4]+=p.optInt("f6");map.put(n,v);}}}}
        catch(Exception e){}
        for(String n:new TreeSet<>(map.keySet())){int[]v=map.get(n);double sr=v[2]==0?0:v[1]*100.0/v[2];c.addView(tv(n+"  • Matches "+v[0]+" • Runs "+v[1]+" • 4s "+v[3]+" • 6s "+v[4]+" • SR "+String.format(Locale.US,"%.1f",sr),13));}
        if(map.isEmpty())c.addView(tv("Completed matches ke baad player stats yahan dikhenge.",14));content.addView(c);
    }

    void saveCurrent(){if(match!=null)prefs.edit().putString("current",match.toString()).apply();}
    void resumeCurrent(){String s=prefs.getString("current",null);if(s==null){toast("Koi current match nahi hai");return;}try{match=new JSONObject(s);innings=match.optInt("battingFirst",0);live();}catch(Exception e){toast("Resume failed");}}
}
