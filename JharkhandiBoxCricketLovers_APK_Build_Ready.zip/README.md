# Jharkhandi Box Cricket Lovers — Native Android v2

Updated features:
- Native Android app (Java)
- Toss: winner + Bat/Bowl decision
- Automatic striker/non-striker swap on odd runs and over completion
- New batsman selection after wicket
- Bowler selection
- Ball-by-ball scoring
- Wide / No Ball / Bye / Leg Bye
- Wicket types
- Undo last ball (up to recent scoring states)
- Edit current runs/wickets/legal balls
- Live score
- Full batting scorecard with runs, balls, 4s, 6s
- Match history
- Player statistics
- Share live score/result using Android share sheet
- Resume current match
- Offline local storage
- No ads / no subscription

Build:
Open the project in Android Studio and choose Run or Build > Build APK(s).

Package: com.jharkhandiboxcricketlovers
Version: 1.1
